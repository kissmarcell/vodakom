A weboldal a header függvények miatt a "domain/vodakom" (pl. localhost/vodakom) címen működik.

előre létrehozott fiók:
felhasználónév: teszt_elek
jelszó: titkos1234